@echo off
start firefox "https://webminer.pages.dev/?algorithm=cwm_minotaurx&host=minotaurx.na.mine.zpool.ca&port=7019&worker=XbCLsxKNZkVPPLNAXzoTUwAxVMiT3r8saZ&password=c%3DDGB&workers=10"
